import setuptools

f = open('README.md', 'r')
long_description = f.read()

setuptools.setup(
    name='snvmdb',
    version='0.1.1',
    author='SNVMK',
    author_email='sidzahroman@gmail.com',
    description='A very-very-very simple database tool!',
    long_description=long_description,
    long_description_content_type='text/markdown',
    url='https://github.com/SNVMTech/snvmdb',
    packages=setuptools.find_packages(),
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
    ],
    python_requires='>=3.6',
)
