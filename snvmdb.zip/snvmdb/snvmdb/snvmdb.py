import json
import os
from typing import Optional

class Database:
    r"""A very simple database!
    
    Usage:

        import snvmdb
        from snvmdb import Database

        db = Database('filename.json')
    """
    def __init__(self, file: Optional[str]):
        self.file = os.path.expanduser(file)
        self.load()

    def load(self):
        try:
            with open(self.file, 'r') as f:
                self.db = json.load(f)
        except FileNotFoundError:
            with open(self.file, 'w+') as f:
                self.db = json.load(f)
        except json.decoder.JSONDecodeError:
            with open(self.file, 'w+') as f:
                f.write(r'{}')
                self.db = json.load(f)

    def save(self):
        with open(self.file, 'w') as f:
            json.dump(self.db, f)

    def create_table(self, table):
        r"""Create table in database
        
        Usage:

            Database.create_table(table)

            or

            tab = Database.create_table(table)
            tab.func()

        Returns:
            A table that was created
        """
        self.db[table] = {}
        self.save()
        return Table(table, self.file)

    def get_table(self, table):
        r"""Get table in database
        
        Usage:

            Database.get_table(table)

            or

            tab = Database.get_table(table)
            tab.func()

        Returns:
            Table
        """
        return Table(table, self.file)

    def show(self):
        r"""Show all DB tables

        Usage:

            Database.show()

        Returns:
            All tables
        """
        for k in self.db.keys():
            return f'table: {k}'
        

class Table:
    r"""An extension to Database to create tables
    """
    def __init__(self, name, file):
        self.name = name
        self.file = file

    def put(self, key, value):
        r"""
        Put data to table

        Usage:

            Table.put(key, value)
        Returns:
            True or False
        """
        with open(self.file, 'r') as f:
            self.db = json.load(f)
            print('a')

        self.db[self.name][key] = value

        with open(self.file, 'w') as f:
            json.dump(self.db, f)

    def drop(self):
        r"""
        Drop table

        Usage:

            Table.drop()
        Returns:
            True or False
        """
        with open(self.file, 'r') as f:
            self.db = json.load(f)

        try:    
            del self.db[self.name]
            return True
        except:
            return False

        with open(self.file, 'w') as f:
            json.dump(self.db, f)

    def del_key(self, key):
        r"""
        Remove pair from table

        Usage:

            Table.del_key(key)
        Returns:
            True or False
        """
        with open(self.file, 'r') as f:
            self.db = json.load(f)

        try:
            del self.db[self.name][key]
            return True
        except:
            return False

        with open(self.file, 'w') as f:
            json.dump(self.db, f)

    def get_key(self, key):
        r"""
        Get key in table

        Usage:

            Table.get(key)
        Returns:
            True or False
        """
        with open(self.file, 'r') as f:
            self.db = json.load(f)

        try:
            return self.db[self.name][key]
            return True
        except:
            return False

    def show(self):
        r"""Show all items in table

        Usage:

            Table.show()

            or

            Database.get_table(table).show()

        Returns:
            All items in table
        """
        for k in self.db.keys():
            try:
                return f'table: {k}'
                return True
            except:
                return False