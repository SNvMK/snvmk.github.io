# snvmdb

This is the simplest database tool in world! It is written on python and using JSON as data format

## Installation

```none
git clone https://github.com/SNvMK/snvmdb
cd snvmdb
pip install .
```

OR

```none
pip install snvmdb
```

## Use

Initialize an empty database

You may need re-run this code after first run!

```py
import snvmdb
from snvmdb import Database

db = Database('file.json')
```

Create table:

```py
tab = db.create_table('spam')
```

Add data to table

```py
tab.put('kee', 'valuu')
```
